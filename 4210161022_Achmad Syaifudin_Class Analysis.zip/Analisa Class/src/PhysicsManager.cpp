#include "PhysicsManager.hpp"

float PhysicsManager::gravityAcceleration = 9.0;
float PhysicsManager::airFriction         = 1.0;
float PhysicsManager::groundFriction      = 1.0;//0.74981231;

